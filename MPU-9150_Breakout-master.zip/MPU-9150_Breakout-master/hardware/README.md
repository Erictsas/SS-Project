Eagle files for the MPU-9150 Breakout. See the commit history for the hardware version numbers.

License: Creative Commons Attribution-ShareAlike 3.0 (CC BY-SA 3.0)
http://creativecommons.org/licenses/by-sa/3.0/
